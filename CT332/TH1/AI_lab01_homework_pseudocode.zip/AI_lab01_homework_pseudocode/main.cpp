#include <cstdio>
#include <vector>
#include <queue>
#include <stack>

#define MAX 3		/* Kich thuoc cua ma tran o so */


/* Cau truc du lieu bieu dien mot trang thai */
struct State {
	int board[MAX][MAX];			/* Ma tran luu 8 o so */
	int empty_col, empty_row;		/* Chi so dong, chi so cot cua o rong */
	struct State *parent;			/* Con tro tro den trang thai cha */
	int behavior;					/* Hanh dong da thuc hien voi trang thai nay */
};


/* Con tro tro den State */
typedef struct State* PState;


/* 
* Ham: Doc du lieu tu file 
* Tham so:	
*		+ char *file_name: ten file du lieu
* Tra ve: Trang thai da doc
*/
PState read_file(char *file_name) {
	FILE *f = fopen(file_name, "rt");
	PState start = new State;
	int i, j;

	/* Nhap du lieu cho ma tran board */
	for(i=0; i<MAX; i++)
		for(j=0; j<MAX; j++) {
			/* Doc du lieu vao */

			/* Neu board[i][j] bang 0 thi ghi nhan vi tri o rong */

		}

	/* Trang thai ban dau khong co cha */
	
	fclose(f);

	return start;
}


/*
* Ham: kiem tra xem hai trang thai state1 va state2 co bang nhau khong
* Tham so:
*		+ PState state1: con tro tro den trang thai 1
*		+ PState state2: con tro tro den trang thai 2
* Tra ve:
*		+ true: state1 bang state2
*		+ false: state1 khong bang state2
*/
bool equals(PState state1, PState state2) {
	for(int i=0; i<MAX; i++) {
		for(int j=0; j<MAX; j++)
			/* Neu phan tu tai vi tri (i, j) cua state1 va state2 khac nhau 
			thi hai trang thai khong bang nhau */

	}
	/* Tat ca cac phan tu trong ma tran bang nhau thi hai trang thai bang nhau */
	
}


/*
* Ham: kiem tra mot trang thai bat ky co phai la trang thai dich cua bai toan hay khong
* Tham so:
*		+ PState state: trang thai can kiem tra
*		+ PState goal: trang thai dich cua bai toan
* Tra ve:
*		+ true: state la trang thai dich
*		+ false: state khong phai la trang thai dich
*/
bool is_goal(PState state, PState goal) {
	/* Kiem tra xem state co bang goal hay khong */
	
}


/*
* Ham: hoan doi gia tri cua hai bien kieu nguyen
* Tham so:
*		+ int *pa: dia chi cua bien thu nhat
*		+ int *pb: dia chi cua bien thu hai
* Tra ve: void
*/
void swap(int *pa, int *pb) {
	/* Hoan doi gia tri cua hai bien co dia chi la pa, pb */

}


/*
* Ham: sao chep mot trang thai
* Tham so:
*		+ PState source: trang thai can sao chep
*		+ PState &destination: trang thai se sao chep vao
* Tra ve: void
*/
void copy_state(PState source, PState &destination) {
	/* Sao chep toan bo cac phan tu trong ma tran board cua source sang destination */
	
	/* Sao chep vi tri o rong tu source sang destination */

}


/*
* Ham: chuyen o rong len tren
* Tham so:
*		+ PState state: trang thai can bien doi
* Tra ve: 
*		+ Trang thai sau khi chuyen o rong len tren: neu chuyen duoc
*		+ NULL: neu khong chuyen duoc
*/
PState move_up(PState state) {
	if(/* Dieu kien de co the chuyen len duoc */) {
		PState result = new State;
		copy_state(state, result);
		/* Thuc hien chuyen doi tren trang thai result va tra ve */

	}
	/* Khong chuyen duoc */

}


/*
* Ham: chuyen o rong xuong duoi
* Tham so:
*		+ PState state: trang thai can bien doi
* Tra ve: 
*		+ Trang thai sau khi chuyen o rong xuong duoi: neu chuyen duoc
*		+ NULL: neu khong chuyen duoc
*/
PState move_down(PState state) {
	/* Thuc hien tuong tu ham move_up */

}


/*
* Ham: chuyen o rong sang trai
* Tham so:
*		+ PState state: trang thai can bien doi
* Tra ve: 
*		+ Trang thai sau khi chuyen o rong sang trai: neu chuyen duoc
*		+ NULL: neu khong chuyen duoc
*/
PState move_left(PState state) {
	/* Thuc hien tuong tu ham move_up */

}


/*
* Ham: chuyen o rong sang phai
* Tham so:
*		+ PState state: trang thai can bien doi
* Tra ve: 
*		+ Trang thai sau khi chuyen o rong sang phai: neu chuyen duoc
*		+ NULL: neu khong chuyen duoc
*/
PState move_right(PState state) {
	/* Thuc hien tuong tu ham move_up */

}


/*
* Ham: goi mot phep toan tren trang thai
* Tham so:
*		+ PState state: trang thai can bien doi
*		+ int op_no: so thu tu cua phep toan (tu quy uoc)
* Tra ve: 
*		+ Trang thai sau khi thuc hien phep toan co so thu tu op_no: neu chuyen duoc
*		+ NULL: neu khong chuyen duoc
*/
PState call_operator(PState state, int op_no) {
	switch(op_no) {
		/* Goi cac phep toan theo tung trung hop cua op_no */

	}
	/* Khong chuyen duoc */

}


/*
* Ham: kiem tra mot trang thai co nam trong vector hay khong
* Tham so:
*		+ PState state: trang thai can kiem tra
*		+ std::vector<PState> v: vector chua cac trang thai
* Tra ve: 
*		+ true: state ton tai trong v
*		+ false: state khong ton tai trong v
*/
bool exist(PState state, std::vector<PState> v) {
	/* Thuc hien kiem tra */

}


/*
* Ham: hien thi mot trang thai ra man hinh
* Tham so:
*		+ PState state: trang thai can hien thi
* Tra ve: void
*/
void print_state(PState state) {
	/* In ma tran board */

}


/*
* Ham: tim kiem breath first search
* Tham so:
*		+ PState state: trang thai bat dau
*		+ PState goal: trang thai dich can tim
* Tra ve: Trang thai dich co chua thong tin parent de hien thi duong di
*/
PState breath_first_search(PState start, PState goal) {
	std::queue<PState> frontier;
	std::vector<PState> explored;

	/* Khoi tao hang doi cho xet */


	while(!frontier.empty()) {
		/* Lay mot trang thai trong frontier ra, goi no la x */


		if(/* x la dich */) {
			/* Tra ve x */

		}

		/* Dua x vao explored */


		/* Phat sinh cac con cua x */
		for(/* Cac con cua x, goi no la y */) {
				if(/* y chua duoc xet */) {
					/* Ghi nhan lai phep toan da thuc hien voi y, cha cua y 
					va dua y vao hang doi cho xet */

				}
		}
	}

	/* Khong tim thay */

}


/*
* Ham: hien thi hanh dong da thuc hien voi trang thai state
* Tham so:
*		+ PState state: Trang thai can hien thi
* Tra ve: void
*/
void print_operator(PState state) {
	switch(state->behavior) {
	case 1:
		printf("Move up:\n");
		print_state(state);
		break;
	case 2:
		printf("Move down:\n");
		print_state(state);
		break;
	case 3:
		printf("Move left:\n");
		print_state(state);
		break;
	case 4:
		printf("Move down:\n");
		print_state(state);
		break;
	}
}


/*
* Ham: Hien thi duong di tu trang thai dau den trang thai dich
* Tham so:
*		+ PState result: ket qua tim kiem cua ham breath_first_search
* Tra ve: Trang thai dich co chua thong tin parent de hien thi duong di
*/
void print_result(PState result) {
	/* Dua cac trang thai vao stack */

	/* Lay cac trang thai trong stack ra va hien thi no ra */

}


/* Ham chinh */
int main(int argc, char const *argv[])
{
	char start_file[] = "start.txt";		/* file chua trang thai ban dau */
	char goal_file[] = "goal.txt";			/* file chua trang thai dich */

	/* Doc trang thai ban dau va trang thai dich tu file */

	/* Tim kiem va hien thi ket qua */

	return 0;
}